<!DOCTYPE html>
<html>
    <head>
        <title>IMS Home_Page-Inventory Management System</title>
        <link rel="stylesheet" type="text/css" href="CSS/ims.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" 
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" 
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
    <body>
        <div class="header"><div class="homepageContainer">
            <a href="Login.php">Login</a>
        </div>
           
        </div>
        <div class="banner">
           <div class="homepageContainer">
               <div class="bannerHeader">
                        <h1>IMS</h1>
                          <p><span class="blue-i">I</span>nventory <span class="blue-i">M</span>anagement <span class="blue-i">S</span>ystem</p>
               </div>
                   <p class="bannerTagline">
                    Track your goods throughout your entire supply chain,from purchasing 
                    to production to end sales
                  </p>
                <div class="bunnericons">
                        <a href=""><i class="fa-brands fa-apple"></i></i></a>
                        <a href=""><i class="fa-brands fa-android"></i></a>
                        <a href=""><i class="fa-brands fa-windows"></i></i></a>
               </div>
           </div>
        </div>
        <div class="homepageContainer">
            <div class="homepagFeatures">
                <div class="homepagFeature">
                    <span class="featureIcon"><i class="fa-solid fa-gear"></i></span>
                    <h1 class="featureTitle">Editable Theme</h1>
                    <p class="featureDescription">Lorem ipsum dolor sit amet, consrctetur adipiscing elit.
                        Suspendisse fringilla gringilla</p>
                </div>
                <div class="homepagFeature">
                    <span class="featureIcon"><i class="fa-solid fa-star"></i></span>
                    <h1 class="featureTitle">Flat Design</h1>
                    <p class="featureDescription">Lorem ipsum dolor sit amet, consrctetur adipiscing elit.
                        Suspendisse fringilla gringilla</p>
                </div>
                <div class="homepagFeature">
                    <span class="featureIcon"><i class="fa-solid fa-earth-asia"></i></span>
                    <h1 class="featureTitle">Reach Your Design</h1>
                    <p class="featureDescription">Lorem ipsum dolor sit amet, consrctetur adipiscing elit.
                        Suspendisse fringilla gringilla</p>
                </div>
           </div>

        </div>
        <div class="homepageNotified">
            <div class="homepageContainer">
                <div class="homepageNotifiedContainer">
                    <div class="emailForm">
                        <h3>Get Notified if Any Updates!</h3>
                        <p>Lorem ipsum dolor sit amet, consrctetur adipiscing elit.
                            Suspendisse fringilla gringillaLorem ipsum dolor sit amet, consrctetur adipiscing elit.
                            Suspendisse fringilla gringillaLorem ipsum dolor sit amet, consrctetur adipiscing elit.
                            Suspendisse fringilla gringillaSuspendisse fringilla gringillaLorem ipsum dolor sit amet, consrctetur adipiscing elit.
                            Suspendisse fringilla gringilla</p>
                            <form action="">
                              <div class="formContainer">
                                <input type="text" placeholder="Email Address"/></input>
                                <button>Notify</button>
                              </div>
                            </form>
                        </div>
                    <div class="video">
                        <iframe src="https://www.youtube.com/embed/48VkVOHYGWw" width="500px" height="300px" frameborder="0"></iframe>
                    </div>
                </div>
            </div>
        </div>
        <div class="socials">
            <div class="homepageContainer">
                <h3 class="socialHeader">Say Hi & Get in Touch</h3>
                <p class="socialtext">Lorem ipsum dolor sit amet, consrctetur adipiscing elit.</p>
                <div class="socialIconsContainer">
                    <a href=""><i class="fa-brands fa-twitter"></i></a>
                    <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                    <a href=""><i class="fa-brands fa-pinterest-p"></i></i></a>
                    <a href=""><i class="fa-brands fa-google-plus-g"></i></i></a>
                    <a href=""><i class="fa-solid fa-link-slash"></i></i></a>
                    <a href=""><i class="fa-brands fa-youtube"></i></i></a>
                </div>
                    
                    

                </div>
            </div>
        </div>
        <div class="footer">
            <div class="homepageContainer">
                <a href="">Contact</a>
                <a href="">Download</a>
                <a href="">Press</a>
                <a href="">Email</a>
                <a href="">Support</a>
                <a href="">Privacy Policy</a>
            </div>
        </div>
    </body>
</html>