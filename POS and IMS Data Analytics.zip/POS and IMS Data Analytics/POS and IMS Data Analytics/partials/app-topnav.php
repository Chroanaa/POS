
<div class="dashboard_topnav">
            <a href="" id="toggleBtn"><i class="fa-solid fa-bars"></i></a>
            <a href="IMS Database/logout.php" id="logoutBtn"><i class="fa-solid fa-power-off"></i>Log-out</a>
        </div>